export default function MenuCalificacionesTributarias() {
  return (
    <div>
      <h1>Calificaciones Tributarias</h1>
      <p>Mantenedor NUAM - Prototipo</p>
    </div>
  );
}
