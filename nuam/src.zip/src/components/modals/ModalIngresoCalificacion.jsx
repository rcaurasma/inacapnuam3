export default function ModalIngresoCalificacion({ onClose }) {
  return (
    <div style={{ background: "#fff", padding: 20, border: "1px solid #ccc" }}>
      <h3>Ingresar Calificación</h3>

      <p>Este modal se completará más adelante.</p>

      <button onClick={onClose}>Cerrar</button>
    </div>
  );
}
