export default function ModalCargaPorFactor({ onClose }) {
  return (
    <div style={{ background: "#fff", padding: 20, border: "1px solid #ccc" }}>
      <h3>Preview Carga Masiva por Factor</h3>

      <p>Este modal se implementará después.</p>

      <button onClick={onClose}>Cerrar</button>
    </div>
  );
}
